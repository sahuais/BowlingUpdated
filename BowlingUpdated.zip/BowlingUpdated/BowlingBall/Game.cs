﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    public class Game:IFrame
    {
        public int Score { get; set; }
        public int frame = 0;           // The current frame
        public int frameScore = 0;      // The total of first two throws in a normal frame
        public int[] throws;            // Input
        public int throw1;              // First throw in a frame
        public int throw2;              // Second throw in a frame
        public int throw3;              // Third throw in the 10th frame

        public List<int> tenFrameScores = new List<int>();
        public int[][] tenFrames = new int[10][]; // a JaggedArray (to allow for three numbers in the 10th frame)

        // OpenFrame records all frames to a data container, to allow for easy scoring
        public void OpenFrame(params int[] throws)
        {
            throw1 = throws[0];
            // In case there is no second number (0) provided when someone throws a strike
            throw2 = (throws.Length == 1) ? 0 : throws[1];
            throw3 = (throws.Length == 3) ? throws[2] : 0;
            frameScore = throw1 + throw2;
            // Store the frame scores in a list as they come in, to be updated with strike and spare bonuses
            tenFrameScores.Add(frameScore);

            // Dynamically populate the JaggedArray tenFrames
            if (throws.Length == 3)
                tenFrames[frame] = new[] { throw1, throw2, throw3 };
            else
                tenFrames[frame] = new[] { throw1, throw2 };

            // Get the number of non-null elements in the tenFrames array
            int numberFramesSoFar = tenFrames.Count(s => s != null);
            
            frame++;

            if (numberFramesSoFar == 10)    // Ready to calculate a score
            { 
                for (int i = 0; i < 10; i++) // iterate through the data container of throws
                {
                    throw1 = tenFrames[i][0];
                    throw2 = tenFrames[i][1];
                    frameScore = tenFrameScores[i];
                    // Strikes and Spares in frames 1-9
                    if (frameScore == 10 && i < 9)
                    {
                        int nextFrameScore = tenFrameScores[i + 1];

                        if (throw1 == 10)   // it's a strike
                        {
                            // Check to see if the next throw was also a strike
                            if (tenFrames[i + 1][0] == 10)   // it's a strike
                            {
                                // bonus = 10 + the first throw of the next frame
                                if (i < 8)
                                {
                                    int strikeBonus = 10 + tenFrames[i + 2][0];
                                    tenFrameScores[i] += strikeBonus;
                                }
                                else  // frame 9, look at just the first two throws of frame 10
                                {
                                    int strikeBonus = tenFrames[i + 1][0] + tenFrames[i + 1][1];              
                                    tenFrameScores[i] += strikeBonus;
                                }
                            }
                            else
                            {
                                // bonus = the total of the two throws in the next frame (nextFrameScore)
                                Console.WriteLine("\tstrikeBonus: " + nextFrameScore);
                                tenFrameScores[i] += nextFrameScore;
                            }
                        }
                        else // spare
                        {                         
                            tenFrameScores[i] += tenFrames[i + 1][0];
                        }
                    }
                    else    // Tenth frame bonuses
                    {
                        if (throw1 == 10) // strike in the tenth frame
                        {
                            // bonus = throw2 + throw3 (throw2 is already included in tenFrameScores[i])
                            tenFrameScores[i] += throw3;
                        }
                        else if (frameScore == 10) // spare in the first two throws of the 10th frame
                        { 
                            tenFrameScores[i] += throw3;
                        }
                    }
                }
                for (int i = 0; i < 10; i++)
                {
                    Score += tenFrameScores[i];                 
                }
            }
        }

    }



}
   

   


