﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingBall
{
    interface IFrame
    {
        void OpenFrame(params int[] throws);

        // Called at the end of the game to get the final score.
        int Score { get; }
       
    }
}
