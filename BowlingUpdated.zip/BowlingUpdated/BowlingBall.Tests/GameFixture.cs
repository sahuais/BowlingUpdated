﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        Game game = new Game();

        [TestMethod]
        public void Gutter_game_score_should_be_zero_test()
        {
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            game.OpenFrame(0, 0);
            Assert.AreEqual(0, game.Score);
        }

        [TestMethod]
        public void TestFrame()
        {
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 10,10);
            Assert.AreEqual(300, game.Score);
        }
        [TestMethod]
        public void Threes()
        {
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            game.OpenFrame(3, 3);
            Assert.AreEqual(60, game.Score);
        }
        [TestMethod]
        public void RandomInputs()
        {
            game.OpenFrame(3, 7);
            game.OpenFrame(9, 1);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(8, 2);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 0);
            game.OpenFrame(9, 1);
            game.OpenFrame(10, 0);
            game.OpenFrame(10, 10, 10);
            Assert.AreEqual(236, game.Score);
        }
    }
}
